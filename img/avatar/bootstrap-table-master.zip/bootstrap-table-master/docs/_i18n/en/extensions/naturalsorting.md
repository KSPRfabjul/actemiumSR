# Table Natural Sorting

Use Plugin: [bootstrap-table-naturalsorting](https://github.com/wenzhixin/bootstrap-table/tree/master/src/extensions/naturalsorting)

## Usage

```html
<script src="extensions/naturalsorting/bootstrap-table-naturalsorting.js"></script>
```

### Options

* Just add data-sorter="alphanum" to any th